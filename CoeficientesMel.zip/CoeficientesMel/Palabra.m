classdef Palabra
    properties
        PalabraContenido
        MatrizMel
        Error
        Correlacion
    end
end

