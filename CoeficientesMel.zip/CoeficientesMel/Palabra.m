classdef Palabra
    properties
        PalabraContenido    % Palabra
        MatrizMel           % Matriz de coeficientes 80x30
        Mse                 % Valor error cuadratico medio
        DistanciaEuclidiana % Valor de distancia
        Correlacion         % Valor de correlacion
    end
end

